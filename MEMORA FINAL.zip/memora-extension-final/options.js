// options.js - saves the user's own Gemini API key into chrome.storage.local.
// No key is ever hardcoded into the extension source.

const geminiKeyInput = document.getElementById('geminiKey');
const saveBtn = document.getElementById('saveBtn');
const savedMsg = document.getElementById('savedMsg');

// Load existing key, if any
chrome.storage.local.get(['geminiApiKey'], (data) => {
  if (data.geminiApiKey) geminiKeyInput.value = data.geminiApiKey;
});

saveBtn.addEventListener('click', () => {
  const geminiApiKey = geminiKeyInput.value.trim();

  if (!geminiApiKey) {
    savedMsg.className = 'text-xs mt-2 min-h-[14px] text-red-400';
    savedMsg.textContent = 'Please enter a Gemini API key.';
    return;
  }

  chrome.storage.local.set({ geminiApiKey }, () => {
    if (chrome.runtime.lastError) {
      savedMsg.className = 'text-xs mt-2 min-h-[14px] text-red-400';
      savedMsg.textContent = 'Failed to save: ' + chrome.runtime.lastError.message;
      return;
    }
    savedMsg.className = 'text-xs mt-2 min-h-[14px] text-green-400';
    savedMsg.textContent = 'Saved! MEMORA will use this key for summaries.';
  });
});
