// popup.js - runs when user clicks the extension icon

const toggleSwitch = document.getElementById('toggleSwitch');
const statusText = document.getElementById('statusText');
const memoryPreview = document.getElementById('memoryPreview');
const memoryTimestamp = document.getElementById('memoryTimestamp');
const clearBtn = document.getElementById('clearBtn');
const settingsLink = document.getElementById('settingsLink');
const historyToggleBtn = document.getElementById('historyToggleBtn');
const historyPanel = document.getElementById('historyPanel');
const historyList = document.getElementById('historyList');
const historyEmptyMsg = document.getElementById('historyEmptyMsg');
const historyNoMatchMsg = document.getElementById('historyNoMatchMsg');
const historySearchInput = document.getElementById('historySearchInput');
const limitBanner = document.getElementById('limitBanner');

// Which site each platform's content script is registered for - used to
// decide whether the currently active tab can actually receive an injection.
const PLATFORM_URL_PATTERNS = {
  chatgpt: ['chat.openai.com', 'chatgpt.com'],
  claude: ['claude.ai'],
  gemini: ['gemini.google.com'],
  perplexity: ['perplexity.ai']
};

let fullHistoryCache = []; // unfiltered, so search can filter client-side instantly

const PLATFORM_LABELS = {
  chatgpt: 'ChatGPT', claude: 'Claude', gemini: 'Gemini', perplexity: 'Perplexity', unknown: 'AI chat'
};

function formatTimeAgo(timestampMs) {
  if (!timestampMs) return '';
  const seconds = Math.floor((Date.now() - timestampMs) / 1000);

  if (seconds < 5) return 'Updated just now';
  if (seconds < 60) return `Updated ${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `Updated ${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  return `Updated ${hours}h ago`;
}

function renderLimitBanner(data) {
  const LIMIT_BANNER_RELEVANT_MS = 2 * 60 * 1000; // only show for 2 minutes after detection
  const detectedAt = data.memoraLimitDetected;
  const isRecent = detectedAt && (Date.now() - detectedAt) < LIMIT_BANNER_RELEVANT_MS;

  if (!isRecent) {
    limitBanner.classList.add('hidden');
    return;
  }

  limitBanner.classList.remove('hidden');

  if (data.memoraLimitHadEnoughContext) {
    limitBanner.className = 'text-[11px] px-2.5 py-2 rounded-lg mb-2 leading-relaxed bg-green-900 text-green-300';
    limitBanner.textContent = '✅ Usage limit detected — memory saved! Safe to switch tools now.';
  } else {
    limitBanner.className = 'text-[11px] px-2.5 py-2 rounded-lg mb-2 leading-relaxed bg-amber-900 text-amber-300';
    limitBanner.textContent = '⚠️ Usage limit detected, but conversation was too short to summarize.';
  }
}

function renderPopupState(data) {
  toggleSwitch.checked = !!data.memoraEnabled;
  statusText.textContent = data.memoraEnabled ? 'ON' : 'OFF';

  renderLimitBanner(data);

  const hasKey = !!data.geminiApiKey;

  if (!hasKey) {
    memoryPreview.textContent = 'Setup needed: add your API key in Settings below.';
    memoryTimestamp.textContent = '';
  } else if (data.memorySnapshot) {
    memoryPreview.textContent = data.memorySnapshot.slice(0, 200) + '...';
    memoryTimestamp.textContent = formatTimeAgo(data.memorySavedAt);
  } else {
    memoryPreview.textContent = 'No memory saved yet. Start chatting on ChatGPT, Gemini, Claude, or Perplexity.';
    memoryTimestamp.textContent = '';
  }
}

// When popup opens, load current state
chrome.storage.local.get(
  ['memoraEnabled', 'memorySnapshot', 'memorySavedAt', 'geminiApiKey', 'memoraLimitDetected', 'memoraLimitHadEnoughContext'],
  renderPopupState
);

// Keep the "Updated Xs ago" text and the limit banner live while the popup is open
setInterval(() => {
  chrome.storage.local.get(
    ['memorySavedAt', 'memoraLimitDetected', 'memoraLimitHadEnoughContext'],
    (data) => {
      if (data.memorySavedAt) {
        memoryTimestamp.textContent = formatTimeAgo(data.memorySavedAt);
      }
      renderLimitBanner(data);
    }
  );
}, 5000);

// Toggle ON/OFF
toggleSwitch.addEventListener('change', () => {
  const enabled = toggleSwitch.checked;
  chrome.storage.local.set({ memoraEnabled: enabled }, () => {
    if (chrome.runtime.lastError) {
      console.error('MEMORA: failed to save toggle state', chrome.runtime.lastError.message);
      return;
    }
    statusText.textContent = enabled ? 'ON' : 'OFF';
  });
});

// Clear ALL memory (history + latest snapshot)
clearBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CLEAR_ALL_MEMORY' }, () => {
    memoryPreview.textContent = 'Memory cleared.';
    memoryTimestamp.textContent = '';
    renderHistory([]);
  });
});

// Open the options page for API key setup
settingsLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

// ---- Memory History ----

function formatHistoryTime(timestampMs) {
  const d = new Date(timestampMs);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) +
    ' ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}

function renderHistory(history) {
  fullHistoryCache = history || [];
  applySearchFilter();
}

function applySearchFilter() {
  const query = historySearchInput.value.trim().toLowerCase();
  const filtered = query
    ? fullHistoryCache.filter((item) => item.text.toLowerCase().includes(query))
    : fullHistoryCache;

  renderFilteredHistory(filtered, query);
}

function renderFilteredHistory(items, activeQuery) {
  historyList.innerHTML = '';

  if (fullHistoryCache.length === 0) {
    historyEmptyMsg.classList.remove('hidden');
    historyNoMatchMsg.classList.add('hidden');
    return;
  }
  historyEmptyMsg.classList.add('hidden');

  if (items.length === 0) {
    historyNoMatchMsg.classList.remove('hidden');
    return;
  }
  historyNoMatchMsg.classList.add('hidden');

  items.forEach((item) => {
    const row = document.createElement('div');
    row.className = 'bg-slate-800 rounded-md p-2 text-[11px]';

    const topRow = document.createElement('div');
    topRow.className = 'flex justify-between items-center mb-1';

    const label = document.createElement('span');
    label.className = 'text-sky-400 font-semibold';
    label.textContent = `${PLATFORM_LABELS[item.source] || item.source} · ${formatHistoryTime(item.savedAt)}`;

    const btnGroup = document.createElement('div');
    btnGroup.className = 'flex gap-2';

    const injectBtn = document.createElement('button');
    injectBtn.textContent = '📤 Inject';
    injectBtn.className = 'text-sky-400 hover:text-sky-300 text-[11px]';
    injectBtn.addEventListener('click', () => injectMemoryIntoActiveTab(item, injectBtn));

    const delBtn = document.createElement('button');
    delBtn.textContent = '✕';
    delBtn.title = 'Delete';
    delBtn.className = 'text-red-400 hover:text-red-300 text-[11px]';
    delBtn.addEventListener('click', () => deleteMemory(item.id));

    btnGroup.appendChild(injectBtn);
    btnGroup.appendChild(delBtn);

    topRow.appendChild(label);
    topRow.appendChild(btnGroup);

    const textEl = document.createElement('div');
    textEl.className = 'text-slate-400';
    textEl.textContent = highlightMatchPreview(item.text, activeQuery);

    row.appendChild(topRow);
    row.appendChild(textEl);
    historyList.appendChild(row);
  });
}

// Shows the text around the first match if there's an active search query,
// instead of always showing the start of the text - makes it actually
// findable when the matching word is buried deep in a long summary.
function highlightMatchPreview(text, activeQuery) {
  const MAX_LEN = 140;

  if (!activeQuery) {
    return text.length > MAX_LEN ? text.slice(0, MAX_LEN) + '...' : text;
  }

  const idx = text.toLowerCase().indexOf(activeQuery);
  if (idx === -1) return text.slice(0, MAX_LEN) + '...';

  const start = Math.max(0, idx - 40);
  const end = Math.min(text.length, idx + activeQuery.length + 60);
  const prefix = start > 0 ? '...' : '';
  const suffix = end < text.length ? '...' : '';

  return prefix + text.slice(start, end) + suffix;
}

historySearchInput.addEventListener('input', applySearchFilter);

function loadHistory() {
  chrome.runtime.sendMessage({ type: 'GET_HISTORY' }, (response) => {
    renderHistory(response?.history || []);
  });
}

// Sends ONE specific saved memory (not necessarily the latest) into whichever
// supported AI tab is currently focused, by messaging that tab's content script.
function injectMemoryIntoActiveTab(item, triggerBtn) {
  const originalLabel = triggerBtn.textContent;
  triggerBtn.textContent = '...';

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const activeTab = tabs[0];
    if (!activeTab || !activeTab.url) {
      triggerBtn.textContent = '⚠️ No tab';
      setTimeout(() => { triggerBtn.textContent = originalLabel; }, 1800);
      return;
    }

    const matchedPlatform = Object.keys(PLATFORM_URL_PATTERNS).find((platform) =>
      PLATFORM_URL_PATTERNS[platform].some((domain) => activeTab.url.includes(domain))
    );

    if (!matchedPlatform) {
      triggerBtn.textContent = '⚠️ Open a supported AI tab';
      setTimeout(() => { triggerBtn.textContent = originalLabel; }, 2200);
      return;
    }

    chrome.tabs.sendMessage(
      activeTab.id,
      { type: 'MANUAL_INJECT_MEMORY', text: item.text },
      (response) => {
        if (chrome.runtime.lastError || !response?.success) {
          triggerBtn.textContent = '⚠️ Failed';
        } else {
          triggerBtn.textContent = '✅ Sent!';
        }
        setTimeout(() => { triggerBtn.textContent = originalLabel; }, 1800);
      }
    );
  });
}

function deleteMemory(id) {
  chrome.runtime.sendMessage({ type: 'DELETE_MEMORY', id }, (response) => {
    if (response?.success) {
      renderHistory(response.history);
      // Refresh the main preview too, since deleting the newest item changes it
      chrome.storage.local.get(
        ['memoraEnabled', 'memorySnapshot', 'memorySavedAt', 'geminiApiKey', 'memoraLimitDetected', 'memoraLimitHadEnoughContext'],
        renderPopupState
      );
    }
  });
}

historyToggleBtn.addEventListener('click', () => {
  const isHidden = historyPanel.classList.contains('hidden');
  historyPanel.classList.toggle('hidden');
  historyToggleBtn.textContent = isHidden ? '📜 Hide Memory History' : '📜 View Memory History';
  if (isHidden) loadHistory();
});
