// content-gemini.js - runs INSIDE gemini.google.com page
// Mirrors content-chatgpt.js: extracts conversation text and sends it for summarization.
// Also reuses the same injection logic as Claude for incoming context.

let lastSentLength = 0;
let summarizing = false;
let alreadyInjected = false;
let mainInterval = null;
let injectionIntervalG = null;

// When the extension is reloaded in chrome://extensions/, any tab that was
// already open keeps running this OLD copy of the script, but its connection
// to chrome.runtime/chrome.storage is severed. Calling those APIs then throws
// "Extension context invalidated." This check lets us detect that state and
// stop cleanly instead of crashing repeatedly in the console.
function extensionContextIsAlive() {
  try {
    return !!(chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

function stopRunningDueToInvalidContext() {
  if (mainInterval) { clearInterval(mainInterval); mainInterval = null; }
  if (injectionIntervalG) { clearInterval(injectionIntervalG); injectionIntervalG = null; }
  console.log("MEMORA: this tab's connection to the extension ended (likely reloaded) - stopping cleanly. Refresh this page to reconnect.");
}

function extractGeminiConversationText() {
  // Gemini's DOM structure: each turn typically lives inside elements with
  // class names like "conversation-container" / "user-query" / "model-response".
  // These selectors may need adjusting as Gemini's UI changes.
  const turns = document.querySelectorAll('[data-test-id="conversation-turn"], .conversation-container');
  let fullText = "";

  turns.forEach((node) => {
    fullText += node.innerText.trim() + "\n\n";
  });

  return fullText.trim();
}

function findGeminiInputBox() {
  return document.querySelector('div[contenteditable="true"], rich-textarea div[contenteditable]');
}

function insertTextIntoEditor(editor, text) {
  editor.focus();
  const inserted = document.execCommand && document.execCommand('insertText', false, text);
  if (!inserted) {
    editor.textContent = text;
  }
  editor.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: text }));
}

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

function checkAndSummarize() {
  if (document.hidden) return;
  if (summarizing) return;
  if (!extensionContextIsAlive()) {
    stopRunningDueToInvalidContext();
    return;
  }

  chrome.storage.local.get(['memoraEnabled'], (data) => {
    if (!data.memoraEnabled) return;

    const text = extractGeminiConversationText();
    if (text.length > 200 && text.length !== lastSentLength) {
      lastSentLength = text.length;
      summarizing = true;

      chrome.runtime.sendMessage(
        { type: "SUMMARIZE_CONVERSATION", text: text, sourcePlatform: "gemini" },
        (response) => {
          summarizing = false;
          if (chrome.runtime.lastError) return;
          if (response?.success) console.log("MEMORA: memory updated from Gemini", response.summary);
        }
      );
    }
  });
}

function injectMemory() {
  if (alreadyInjected) return;
  if (!extensionContextIsAlive()) return; // stay silent, checkAndSummarize already logs the stop message

  chrome.storage.local.get(['memoraEnabled', 'memorySnapshot'], (data) => {
    if (!data.memoraEnabled || !data.memorySnapshot) return;

    const inputBox = findGeminiInputBox();
    if (!inputBox) return;
    if (inputBox.innerText.trim().length > 0) return;

    const snapshotKey = 'memora_injected_' + simpleHash(data.memorySnapshot);
    if (sessionStorage.getItem(snapshotKey)) {
      alreadyInjected = true;
      return;
    }

    const contextMessage =
      "Here is context from my previous conversation on another AI tool:\n\n" +
      data.memorySnapshot +
      "\n\nPlease acknowledge you understand this, then we'll continue.";

    insertTextIntoEditor(inputBox, contextMessage);
    sessionStorage.setItem(snapshotKey, '1');
    alreadyInjected = true;
    console.log("MEMORA: context injected into Gemini");
  });
}

// ---- Manual injection on demand (triggered from the popup's history list) ----
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== "MANUAL_INJECT_MEMORY") return;

  const inputBox = findGeminiInputBox();
  if (!inputBox) {
    sendResponse({ success: false, reason: "Could not find Gemini's input box on this page." });
    return;
  }

  const contextMessage =
    "Here is context from a previous conversation on another AI tool:\n\n" +
    message.text +
    "\n\nPlease acknowledge you understand this, then we'll continue.";

  insertTextIntoEditor(inputBox, contextMessage);
  sendResponse({ success: true });
});

mainInterval = setInterval(checkAndSummarize, 6000);
window.addEventListener('load', () => setTimeout(checkAndSummarize, 2000));
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) checkAndSummarize();
});

injectionIntervalG = setInterval(() => {
  injectMemory();
  if (alreadyInjected && injectionIntervalG) {
    clearInterval(injectionIntervalG);
    injectionIntervalG = null;
  }
}, 2000);
setTimeout(() => {
  if (injectionIntervalG) { clearInterval(injectionIntervalG); injectionIntervalG = null; }
}, 30000);
