// content-chatgpt.js - runs INSIDE chatgpt.com / chat.openai.com page
// Job 1: read the conversation text, send to background.js for summarization
// Job 2: if we have a saved memory and the input box is empty, auto-inject it
//        (same "writing" behavior as content-claude.js / content-gemini.js / content-perplexity.js)

let lastSentLength = 0;
let summarizing = false;
let alreadyInjected = false;
let limitAlertShown = false;
let mainInterval = null;
let injectionIntervalC = null;

// See content-gemini.js for full explanation: this detects when the tab is
// running a stale copy of the script after the extension was reloaded, so we
// can stop cleanly instead of throwing "Extension context invalidated" errors.
function extensionContextIsAlive() {
  try {
    return !!(chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

function stopRunningDueToInvalidContext() {
  if (mainInterval) {
    clearInterval(mainInterval);
    mainInterval = null;
  }
  if (injectionIntervalC) {
    clearInterval(injectionIntervalC);
    injectionIntervalC = null;
  }
  console.log("MEMORA: this tab's connection to the extension ended (likely reloaded) - stopping cleanly. Refresh this page to reconnect.");
}

// Common phrases ChatGPT shows when a usage limit is hit. Checked against the
// page's visible text - if any of these appear, we treat it as "user is about
// to be forced to switch tools" and trigger an immediate summary attempt,
// in addition to (not instead of) the normal periodic check below.
const LIMIT_PHRASES = [
  "you've reached the current usage limit",
  "you have reached the current usage limit",
  "you've reached your message limit",
  "you have reached your message limit",
  "try again later",
  "usage limit"
];

function pageLooksLimitHit() {
  // Keep this cheap: just check the body's visible text for known phrases,
  // don't re-parse the whole DOM tree.
  const bodyText = document.body.innerText.toLowerCase();
  return LIMIT_PHRASES.some((phrase) => bodyText.includes(phrase));
}

function extractConversationText() {
  // ChatGPT messages are usually inside elements with data-message-author-role
  const messageNodes = document.querySelectorAll('[data-message-author-role]');
  let fullText = "";

  messageNodes.forEach((node) => {
    const role = node.getAttribute('data-message-author-role');
    fullText += `${role.toUpperCase()}: ${node.innerText}\n\n`;
  });

  return fullText.trim();
}

function checkAndSummarize() {
  // Skip work entirely if the tab isn't visible - saves API calls/quota
  if (document.hidden) return;
  if (summarizing) return; // don't overlap requests
  if (!extensionContextIsAlive()) {
    stopRunningDueToInvalidContext();
    return;
  }

  chrome.storage.local.get(['memoraEnabled'], (data) => {
    if (!data.memoraEnabled) return; // extension is OFF, do nothing

    const text = extractConversationText();
    const limitHit = pageLooksLimitHit();

    // Two reasons to summarize now:
    // 1. Normal case: conversation grew since we last checked (the existing behavior)
    // 2. Fast-path: a usage-limit message just appeared on screen - the user is
    //    about to be forced to switch tools, so we make sure memory is fresh
    //    RIGHT NOW even if nothing "grew" since the last periodic check.
    const grewSinceLastCheck = text.length > 200 && text.length !== lastSentLength;
    const shouldSummarizeNow = grewSinceLastCheck || (limitHit && !limitAlertShown && text.length > 200);

    if (limitHit && !limitAlertShown) {
      limitAlertShown = true;
      const savedFreshMemory = text.length > 200;
      chrome.storage.local.set({
        memoraLimitDetected: Date.now(),
        memoraLimitHadEnoughContext: savedFreshMemory
      });
      console.log("MEMORA: usage limit detected on ChatGPT" +
        (savedFreshMemory ? " - forcing an immediate memory save" : " - conversation too short to summarize"));
    }

    if (shouldSummarizeNow) {
      lastSentLength = text.length;
      summarizing = true;

      chrome.runtime.sendMessage(
        { type: "SUMMARIZE_CONVERSATION", text: text, sourcePlatform: "chatgpt" },
        (response) => {
          summarizing = false;
          if (chrome.runtime.lastError) {
            console.warn("MEMORA: message failed", chrome.runtime.lastError.message);
            return;
          }
          if (response?.success) {
            console.log("MEMORA: memory updated", response.summary);
          }
        }
      );
    }
  });
}

// ---- Injection ("writing") logic, mirrors content-claude.js ----

function findChatGPTInputBox() {
  // ChatGPT's composer has used different markup over time:
  // - a <textarea id="prompt-textarea">
  // - a contenteditable div with id="prompt-textarea" (ProseMirror-based)
  // Try both, newest first.
  return document.querySelector('#prompt-textarea, div[contenteditable="true"]#prompt-textarea')
      || document.querySelector('textarea[data-id="root"]')
      || document.querySelector('div[contenteditable="true"]')
      || document.querySelector('textarea');
}

function getBoxText(box) {
  return box.tagName === 'TEXTAREA' ? box.value : box.innerText;
}

function insertTextIntoChatGPTBox(box, text) {
  box.focus();

  if (box.tagName === 'TEXTAREA') {
    box.value = text;
    // React-controlled inputs need a native input event to notice the change
    box.dispatchEvent(new Event('input', { bubbles: true }));
    return;
  }

  // contenteditable / ProseMirror path
  const inserted = document.execCommand && document.execCommand('insertText', false, text);
  if (!inserted) {
    box.textContent = text;
  }
  box.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: text }));
}

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

function injectMemory() {
  if (alreadyInjected) return;
  if (!extensionContextIsAlive()) return;

  chrome.storage.local.get(['memoraEnabled', 'memorySnapshot'], (data) => {
    if (!data.memoraEnabled) return;
    if (!data.memorySnapshot) return;

    const inputBox = findChatGPTInputBox();
    if (!inputBox) return; // page not fully loaded yet, will retry

    // Only inject if box is currently empty (don't overwrite user typing)
    if (getBoxText(inputBox).trim().length > 0) return;

    // Avoid re-injecting the exact same snapshot repeatedly in this tab/session
    const snapshotKey = 'memora_injected_' + simpleHash(data.memorySnapshot);
    if (sessionStorage.getItem(snapshotKey)) {
      alreadyInjected = true;
      return;
    }

    const contextMessage =
      "Here is context from my previous conversation on another AI tool:\n\n" +
      data.memorySnapshot +
      "\n\nPlease acknowledge you understand this, then we'll continue.";

    insertTextIntoChatGPTBox(inputBox, contextMessage);

    sessionStorage.setItem(snapshotKey, '1');
    alreadyInjected = true;
    console.log("MEMORA: context injected into ChatGPT");
  });
}

// ---- Manual injection on demand (triggered from the popup's history list) ----
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== "MANUAL_INJECT_MEMORY") return;

  const inputBox = findChatGPTInputBox();
  if (!inputBox) {
    sendResponse({ success: false, reason: "Could not find ChatGPT's input box on this page." });
    return;
  }

  const contextMessage =
    "Here is context from a previous conversation on another AI tool:\n\n" +
    message.text +
    "\n\nPlease acknowledge you understand this, then we'll continue.";

  insertTextIntoChatGPTBox(inputBox, contextMessage);
  sendResponse({ success: true });
});

// Re-check every 6 seconds while user is chatting (faster catch-up than before)
mainInterval = setInterval(checkAndSummarize, 6000);

// Also trigger once on page load
window.addEventListener('load', () => {
  setTimeout(checkAndSummarize, 2000);
});

// Catch up immediately when the user comes back to this tab, instead of
// waiting for the next 6-second tick
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) checkAndSummarize();
});

// ChatGPT loads dynamically, so retry injection every 2 seconds until the box appears
injectionIntervalC = setInterval(() => {
  injectMemory();
  if (alreadyInjected && injectionIntervalC) {
    clearInterval(injectionIntervalC);
    injectionIntervalC = null;
  }
}, 2000);

// Stop trying after 30 seconds regardless
setTimeout(() => {
  if (injectionIntervalC) { clearInterval(injectionIntervalC); injectionIntervalC = null; }
}, 30000);
