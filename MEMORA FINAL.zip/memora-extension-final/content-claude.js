// content-claude.js - runs INSIDE claude.ai page
// Job 1 (NEW): read the conversation text, send to background.js for summarization
//              - same "reading" behavior as content-chatgpt.js / content-gemini.js / content-perplexity.js
// Job 2: check if we have a saved memory, and if input box is empty, auto-inject it

let lastSentLength = 0;
let summarizing = false;
let alreadyInjected = false;
let readingInterval = null;
let injectionInterval = null;

// See content-gemini.js for full explanation: this detects when the tab is
// running a stale copy of the script after the extension was reloaded, so we
// can stop cleanly instead of throwing "Extension context invalidated" errors.
function extensionContextIsAlive() {
  try {
    return !!(chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

function stopRunningDueToInvalidContext() {
  if (readingInterval) { clearInterval(readingInterval); readingInterval = null; }
  if (injectionInterval) { clearInterval(injectionInterval); injectionInterval = null; }
  console.log("MEMORA: this tab's connection to the extension ended (likely reloaded) - stopping cleanly. Refresh this page to reconnect.");
}

// ---- Reading ("capture") logic ----

function extractClaudeConversationText() {
  // Claude's chat UI does not publish a stable public selector contract, so
  // this tries several reasonably likely patterns, falling back gracefully.
  // If MEMORA stops capturing Claude conversations after a Claude.ai UI
  // update, this is the function to re-check against the live DOM first.
  const candidates = [
    '[data-testid="user-message"], [data-testid="assistant-message"]',
    '[data-test-render-count] [class*="font-claude"]',
    'div[class*="message"]'
  ];

  for (const selector of candidates) {
    const nodes = document.querySelectorAll(selector);
    if (nodes.length > 0) {
      let fullText = "";
      nodes.forEach((node) => {
        fullText += node.innerText.trim() + "\n\n";
      });
      return fullText.trim();
    }
  }

  return "";
}

function checkAndSummarize() {
  if (document.hidden) return;
  if (summarizing) return;
  if (!extensionContextIsAlive()) {
    stopRunningDueToInvalidContext();
    return;
  }

  chrome.storage.local.get(['memoraEnabled'], (data) => {
    if (!data.memoraEnabled) return;

    const text = extractClaudeConversationText();

    if (text.length > 200 && text.length !== lastSentLength) {
      lastSentLength = text.length;
      summarizing = true;

      chrome.runtime.sendMessage(
        { type: "SUMMARIZE_CONVERSATION", text: text, sourcePlatform: "claude" },
        (response) => {
          summarizing = false;
          if (chrome.runtime.lastError) {
            console.warn("MEMORA: message failed", chrome.runtime.lastError.message);
            return;
          }
          if (response?.success) {
            console.log("MEMORA: memory updated from Claude", response.summary);
          }
        }
      );
    }
  });
}

// ---- Writing ("injection") logic ----

function findClaudeInputBox() {
  // Claude's composer is a ProseMirror-based contenteditable div.
  // Selector may need adjusting if Claude updates their site structure.
  return document.querySelector('div[contenteditable="true"]');
}

// ProseMirror/contenteditable editors often ignore execCommand('insertText')
// or mishandle it. Dispatching real input events is more reliable.
function insertTextIntoEditor(editor, text) {
  editor.focus();

  const inserted = document.execCommand && document.execCommand('insertText', false, text);

  if (!inserted) {
    editor.textContent = text;
    editor.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: text }));
  } else {
    editor.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: text }));
  }
}

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

function injectMemory() {
  if (alreadyInjected) return;
  if (!extensionContextIsAlive()) return; // checkAndSummarize already logs the stop message

  chrome.storage.local.get(['memoraEnabled', 'memorySnapshot'], (data) => {
    if (!data.memoraEnabled) return;
    if (!data.memorySnapshot) return;

    const inputBox = findClaudeInputBox();
    if (!inputBox) return; // page not fully loaded yet, will retry

    if (inputBox.innerText.trim().length > 0) return;

    const snapshotKey = 'memora_injected_' + simpleHash(data.memorySnapshot);
    if (sessionStorage.getItem(snapshotKey)) {
      alreadyInjected = true;
      return;
    }

    const contextMessage =
      "Here is context from my previous conversation on another AI tool:\n\n" +
      data.memorySnapshot +
      "\n\nPlease acknowledge you understand this, then we'll continue.";

    insertTextIntoEditor(inputBox, contextMessage);

    sessionStorage.setItem(snapshotKey, '1');
    alreadyInjected = true;
    console.log("MEMORA: context injected into Claude");
  });
}

// ---- Manual injection on demand (triggered from the popup's history list) ----
// Lets the user pick ANY saved memory - not just the latest - and push it
// into whichever supported AI tab is currently active.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== "MANUAL_INJECT_MEMORY") return;

  const inputBox = findClaudeInputBox();
  if (!inputBox) {
    sendResponse({ success: false, reason: "Could not find Claude's input box on this page." });
    return;
  }

  const contextMessage =
    "Here is context from a previous conversation on another AI tool:\n\n" +
    message.text +
    "\n\nPlease acknowledge you understand this, then we'll continue.";

  insertTextIntoEditor(inputBox, contextMessage);
  sendResponse({ success: true });
});

// ---- Timers for both jobs ----

// Reading: re-check every 6 seconds while user is chatting
readingInterval = setInterval(checkAndSummarize, 6000);
window.addEventListener('load', () => setTimeout(checkAndSummarize, 2000));
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) checkAndSummarize();
});

// Writing: Claude loads dynamically, so retry every 2 seconds until input box appears
injectionInterval = setInterval(() => {
  injectMemory();
  if (alreadyInjected && injectionInterval) {
    clearInterval(injectionInterval);
    injectionInterval = null;
  }
}, 2000);
setTimeout(() => {
  if (injectionInterval) { clearInterval(injectionInterval); injectionInterval = null; }
}, 30000);
