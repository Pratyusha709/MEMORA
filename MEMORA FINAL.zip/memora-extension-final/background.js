// background.js - the central coordinator
// Handles: receiving raw conversation text, calling Gemini, saving the summary
//
// The user supplies their OWN free Gemini API key on the options page.
// No key is ever hardcoded in this source file.

const GEMINI_MODEL_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";

const MAX_HISTORY_ITEMS = 20; // keep storage small, no need for unlimited history

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "SUMMARIZE_CONVERSATION") {
    summarizeConversation(message.text).then((summary) => {
      const isError = summary.startsWith("Could not summarize") || summary.startsWith("Setup needed") || summary.startsWith("Summary unavailable");

      if (isError) {
        // Don't pollute history with failed attempts - just surface the error for this session
        chrome.storage.local.set({ memorySnapshot: summary, memorySavedAt: Date.now(), memoryIsError: true }, () => {
          sendResponse({ success: false, summary });
        });
        return;
      }

      saveToHistory(summary, message.sourcePlatform || "unknown").then(() => {
        chrome.storage.local.set({ memoryIsError: false });
        sendResponse({ success: true, summary });
      });
    });
    return true; // keep channel open for async response
  }

  if (message.type === "GET_MEMORY") {
    chrome.storage.local.get(['memorySnapshot', 'memoraEnabled'], (data) => {
      sendResponse(data);
    });
    return true;
  }

  if (message.type === "GET_HISTORY") {
    chrome.storage.local.get(['memoryHistory'], (data) => {
      sendResponse({ history: data.memoryHistory || [] });
    });
    return true;
  }

  if (message.type === "DELETE_MEMORY") {
    chrome.storage.local.get(['memoryHistory'], (data) => {
      const history = data.memoryHistory || [];
      const updated = history.filter((item) => item.id !== message.id);
      const newLatest = updated[0]; // history is stored newest-first

      chrome.storage.local.set(
        {
          memoryHistory: updated,
          memorySnapshot: newLatest ? newLatest.text : "",
          memorySavedAt: newLatest ? newLatest.savedAt : null
        },
        () => sendResponse({ success: true, history: updated })
      );
    });
    return true;
  }

  if (message.type === "CLEAR_ALL_MEMORY") {
    chrome.storage.local.set(
      { memoryHistory: [], memorySnapshot: "", memorySavedAt: null },
      () => sendResponse({ success: true })
    );
    return true;
  }
});

// Adds a new summary to the front of the history list, trims old entries,
// and keeps memorySnapshot/memorySavedAt pointing at the newest one so
// content-claude.js (which only reads memorySnapshot) keeps working unchanged.
async function saveToHistory(summaryText, sourcePlatform) {
  const { memoryHistory } = await chrome.storage.local.get(['memoryHistory']);
  const history = memoryHistory || [];

  const newEntry = {
    id: `mem_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    text: summaryText,
    source: sourcePlatform,
    savedAt: Date.now()
  };

  const updated = [newEntry, ...history].slice(0, MAX_HISTORY_ITEMS);

  return chrome.storage.local.set({
    memoryHistory: updated,
    memorySnapshot: newEntry.text,
    memorySavedAt: newEntry.savedAt
  });
}

function buildPrompt(conversationText) {
  const MAX_CHARS = 20000;
  const trimmedText = conversationText.length > MAX_CHARS
    ? conversationText.slice(-MAX_CHARS) // keep the most recent part of the conversation
    : conversationText;

  return `Summarize this AI conversation into a short structured memory snapshot.
Include only:
- Project: what is being built/discussed
- Goals: what the user wants to achieve
- Key decisions made so far
- Current progress / where the conversation left off
- User preferences (tone, style, format if mentioned)

Keep it under 12 lines, plain text, no markdown symbols.

Conversation:
${trimmedText}`;
}

async function summarizeConversation(conversationText) {
  const { geminiApiKey } = await chrome.storage.local.get(['geminiApiKey']);
  return summarizeWithGemini(conversationText, geminiApiKey);
}

async function summarizeWithGemini(conversationText, geminiApiKey) {
  if (!geminiApiKey) {
    console.warn("MEMORA: no Gemini API key set. Open the extension options to add one.");
    return "Setup needed: add your free Gemini API key in MEMORA settings (right-click the extension icon > Options).";
  }

  const prompt = buildPrompt(conversationText);

  try {
    const response = await fetch(`${GEMINI_MODEL_URL}?key=${geminiApiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });

    if (!response.ok) {
      const errBody = await response.text();
      console.error("MEMORA: Gemini API error", response.status, errBody);
      if (response.status === 400 || response.status === 403) {
        return "Could not summarize: your Gemini API key looks invalid. Check it in MEMORA settings.";
      }
      if (response.status === 429) {
        return "Could not summarize: Gemini rate limit hit. Try again shortly.";
      }
      return "Could not summarize - Gemini API returned an error.";
    }

    const data = await response.json();
    const summary = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!summary) {
      console.error("MEMORA: unexpected Gemini response shape", data);
      return "Summary unavailable - unexpected API response.";
    }

    return summary.trim();
  } catch (err) {
    console.error("MEMORA summarization error (Gemini):", err);
    return "Could not summarize - check your network connection.";
  }
}
