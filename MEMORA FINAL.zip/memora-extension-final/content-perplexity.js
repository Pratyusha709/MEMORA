// content-perplexity.js - runs INSIDE perplexity.ai page
// Mirrors content-chatgpt.js / content-gemini.js for extraction + injection.

let lastSentLength = 0;
let summarizing = false;
let alreadyInjected = false;
let readingInterval = null;
let injectionIntervalP = null;

// See content-gemini.js for full explanation: this detects when the tab is
// running a stale copy of the script after the extension was reloaded, so we
// can stop cleanly instead of throwing "Extension context invalidated" errors.
function extensionContextIsAlive() {
  try {
    return !!(chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

function stopRunningDueToInvalidContext() {
  if (readingInterval) { clearInterval(readingInterval); readingInterval = null; }
  if (injectionIntervalP) { clearInterval(injectionIntervalP); injectionIntervalP = null; }
  console.log("MEMORA: this tab's connection to the extension ended (likely reloaded) - stopping cleanly. Refresh this page to reconnect.");
}

function extractPerplexityConversationText() {
  // Perplexity threads typically render Q&A blocks. Selector may need
  // adjusting as Perplexity's UI changes.
  const blocks = document.querySelectorAll('[data-testid="answer"], .prose, [class*="query"]');
  let fullText = "";

  blocks.forEach((node) => {
    fullText += node.innerText.trim() + "\n\n";
  });

  return fullText.trim();
}

function findPerplexityInputBox() {
  return document.querySelector('textarea, div[contenteditable="true"]');
}

function insertText(el, text) {
  el.focus();
  if (el.tagName === 'TEXTAREA') {
    el.value = text;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  } else {
    const inserted = document.execCommand && document.execCommand('insertText', false, text);
    if (!inserted) el.textContent = text;
    el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: text }));
  }
}

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

function checkAndSummarize() {
  if (document.hidden) return;
  if (summarizing) return;
  if (!extensionContextIsAlive()) {
    stopRunningDueToInvalidContext();
    return;
  }

  chrome.storage.local.get(['memoraEnabled'], (data) => {
    if (!data.memoraEnabled) return;

    const text = extractPerplexityConversationText();
    if (text.length > 200 && text.length !== lastSentLength) {
      lastSentLength = text.length;
      summarizing = true;

      chrome.runtime.sendMessage(
        { type: "SUMMARIZE_CONVERSATION", text: text, sourcePlatform: "perplexity" },
        (response) => {
          summarizing = false;
          if (chrome.runtime.lastError) return;
          if (response?.success) console.log("MEMORA: memory updated from Perplexity", response.summary);
        }
      );
    }
  });
}

function injectMemory() {
  if (alreadyInjected) return;
  if (!extensionContextIsAlive()) return;

  chrome.storage.local.get(['memoraEnabled', 'memorySnapshot'], (data) => {
    if (!data.memoraEnabled || !data.memorySnapshot) return;

    const inputBox = findPerplexityInputBox();
    if (!inputBox) return;

    const currentText = inputBox.tagName === 'TEXTAREA' ? inputBox.value : inputBox.innerText;
    if (currentText.trim().length > 0) return;

    const snapshotKey = 'memora_injected_' + simpleHash(data.memorySnapshot);
    if (sessionStorage.getItem(snapshotKey)) {
      alreadyInjected = true;
      return;
    }

    const contextMessage =
      "Here is context from my previous conversation on another AI tool:\n\n" +
      data.memorySnapshot +
      "\n\nPlease acknowledge you understand this, then we'll continue.";

    insertText(inputBox, contextMessage);
    sessionStorage.setItem(snapshotKey, '1');
    alreadyInjected = true;
    console.log("MEMORA: context injected into Perplexity");
  });
}

// ---- Manual injection on demand (triggered from the popup's history list) ----
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== "MANUAL_INJECT_MEMORY") return;

  const inputBox = findPerplexityInputBox();
  if (!inputBox) {
    sendResponse({ success: false, reason: "Could not find Perplexity's input box on this page." });
    return;
  }

  const contextMessage =
    "Here is context from a previous conversation on another AI tool:\n\n" +
    message.text +
    "\n\nPlease acknowledge you understand this, then we'll continue.";

  insertText(inputBox, contextMessage);
  sendResponse({ success: true });
});

readingInterval = setInterval(checkAndSummarize, 6000);
window.addEventListener('load', () => setTimeout(checkAndSummarize, 2000));
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) checkAndSummarize();
});

injectionIntervalP = setInterval(() => {
  injectMemory();
  if (alreadyInjected && injectionIntervalP) {
    clearInterval(injectionIntervalP);
    injectionIntervalP = null;
  }
}, 2000);
setTimeout(() => {
  if (injectionIntervalP) { clearInterval(injectionIntervalP); injectionIntervalP = null; }
}, 30000);
